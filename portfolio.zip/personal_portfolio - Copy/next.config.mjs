/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['dial4college.blr1.cdn.digitaloceanspaces.com'],
      },
};

export default nextConfig;
